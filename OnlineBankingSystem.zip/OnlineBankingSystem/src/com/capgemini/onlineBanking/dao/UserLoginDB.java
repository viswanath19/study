package com.capgemini.onlineBanking.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.onlineBanking.Util.RechargeDBConnection;
import com.capgemini.onlineBanking.bean.UserAccountBean;
import com.capgemini.onlineBanking.exception.onlineBankingException;

public class UserLoginDB implements IUserLogin {

	@Override
	public String LoginValidation(String userName, String pwd) {
		String password=null;
		String result = "false";
		String status=null;
		UserAccountBean rb=new UserAccountBean();
		long accountno;
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");  
		  
		//step2 create  the connection object  
		Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
		  
		//step3 create the statement object  
		Statement stmt=con.createStatement();  
		  
		//step4 execute query  
		PreparedStatement pmstmt=con.prepareStatement(IQueryMapper.validateUser);
		pmstmt.setString(1, userName);
		ResultSet rs=pmstmt.executeQuery();
		
		if(rs!=null){
			
			while(rs.next()){
				//System.out.println("hello");
				password=rs.getString(2);
				accountno=rs.getLong(1);
				status=rs.getString(3);
				//System.out.println(password);
				//System.out.println(pwd);
				
				if(password.equals(pwd)&&status.equals("U")){
					//rb.setAccNumber(accountno);
					result=String.valueOf(accountno);
					//System.out.println(result);
				}
				else{
					result="false";
					//System.out.println(result);
				}
				//sb.append(planname+"      "+Integer.toString(amount)+"\n");
				//System.out.println(details);
				
			}
		}
		//step5 close the connection object  
		con.close();  
		  
		}catch(Exception e){ 
			//msg=e.getMessage();
		}

		return result;
	}

	@Override
	public boolean getRegistered(UserAccountBean useraccountbean) throws onlineBankingException {
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			String s1=IQueryMapper.registerUser;
			PreparedStatement s=con.prepareStatement(s1);
			//String s2="select rec_seq.nextval from dual";
			java.sql.Statement sw=con.createStatement();
			//ResultSet r1=sw.executeQuery(s2);
			//s.executeUpdate();
			s=con.prepareStatement(s1);
			//s.setInt(1,val);
			s.setLong(1,useraccountbean.getAccountNo());
			s.setLong(2,useraccountbean.getUserid());
			s.setString(3, useraccountbean.getLoginpassword());
			s.setString(4, useraccountbean.getSecurityQuestion());
		    s.setString(5,useraccountbean.getSecurityAnswer());
			s.setString(6,useraccountbean.getTransPassword());
			s.setString(7, useraccountbean.getLockStatus());
			
			int result=s.executeUpdate();
			if(result>0){
				System.out.println("Values inserted successfully");
			}
			else{
				throw new onlineBankingException("Please Create your Bank Account to opt online Banking");
			}
			}
			catch(Exception e){
				throw new onlineBankingException("Please Create your Bank Account to opt online Banking");
			}
			return false;
	}

	@Override
	public String getMiniStatement(long account) throws ClassNotFoundException, IOException, SQLException {
		String trans_details=null;
		Long acc_no;
		long trans_id=0;
		StringBuilder sb=new StringBuilder();
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");   
		//step2 create  the connection object  
		Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
		Statement stmt=con.createStatement();  
		  
		//step4 execute query  
		PreparedStatement pmstmt=con.prepareStatement(IQueryMapper.miniStatement);
		pmstmt.setLong(1, account);
		ResultSet rs=pmstmt.executeQuery();
		
		if(rs!=null){
			while(rs.next()){
				//account=rs.getLong(1);
				trans_details=rs.getString(3);
				//System.out.println(trans_details);
				acc_no=rs.getLong(1);
				trans_id=rs.getLong(2);
				
				sb.append(acc_no+"                   "+trans_id+"                 "+trans_details+"\n");
			}
		}
		con.close();  
		  
	}catch(Exception e){ 
		//msg=e.getMessage();
	}
		// TODO Auto-generated method stub
		return sb.toString();
	}

	@Override
	public boolean validatePayee(long account, long paccount) {
		long payeraccount;
		int i=0;
		long paccounts[]=new long[100];
		boolean validatePayee=false;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			  
			//step3 create the statement object  
			Statement stmt=con.createStatement();  
			String PayeeValidation=IQueryMapper.validatePayee;
			PreparedStatement pmstmt=con.prepareStatement(PayeeValidation);
			pmstmt.setLong(1, account);
			//step4 execute query  
			ResultSet rs=pmstmt.executeQuery(); 
			if(rs!=null){
				while(rs.next()){
					payeraccount=rs.getLong(1);
					paccounts[i++]=payeraccount;
				}
			}
			for(i=0;i<paccounts.length;i++){
			if(paccounts[i]==paccount){
				validatePayee=true;
			}
			}
			//System.out.println(sb);
			//step5 close the connection object  
			con.close();  
			  
			}catch(Exception e){ 
				//msg=e.getMessage();
			}
		return validatePayee;
	}

	@Override
	public String transferFunds(long account, long paccount, int amount,String password) {
		long userBalance=0;
		long payeeBalance=0;
		String pwd=null;
		String fundTransfer="false";
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			  
			//step3 create the statement object  
			Statement stmt=con.createStatement();  
			  
			//step4 execute query  
			String transPassword=IQueryMapper.validateTransPassword;
			PreparedStatement pmstmt=con.prepareStatement(transPassword);
			pmstmt.setLong(1,account);
			ResultSet resultset=pmstmt.executeQuery();
			if(resultset!=null){
				while(resultset.next()){
					pwd=resultset.getString(1);
				}
			}
			if(password.equals(pwd)){
			String accountBalance=IQueryMapper.userBalance;
			pmstmt=con.prepareStatement(accountBalance);
			pmstmt.setLong(1, account);
			ResultSet rs=pmstmt.executeQuery(); 
			if(rs!=null){
				while(rs.next()){
					userBalance=rs.getLong(1);
				}
			}
			pmstmt=con.prepareStatement(IQueryMapper.payeeBalance);
			pmstmt.setLong(1, paccount);
			ResultSet rs1=pmstmt.executeQuery(); 
			if(rs1!=null){
				while(rs1.next()){
					payeeBalance=rs1.getLong(1);
				}
			}
			userBalance=userBalance-amount;
			payeeBalance=payeeBalance+amount;
			pmstmt=con.prepareStatement(IQueryMapper.updateUserBalance);
			pmstmt.setLong(1, userBalance);
			pmstmt.setLong(2, account);
			int userresult=pmstmt.executeUpdate();
			pmstmt=con.prepareStatement(IQueryMapper.updatePayeeBalance);
			pmstmt.setLong(1, payeeBalance);
			pmstmt.setLong(2, paccount);
			int payeeresult=pmstmt.executeUpdate();
			if(userresult>0&&payeeresult>0){
				long trans_id=0;
				String trans_seq_id=IQueryMapper.transaction_id;
				ResultSet resultSet=stmt.executeQuery(trans_seq_id);
				if(resultSet!=null){
					while(resultSet.next()){
						trans_id=resultSet.getLong(1);
					}
				}
				pmstmt=con.prepareStatement(IQueryMapper.transaction_Details);
				pmstmt.setLong(1, trans_id);
				pmstmt.setString(2, "Online Transaction");
				pmstmt.setString(3, "N");
				pmstmt.setLong(4, amount);
				pmstmt.setLong(5, account);
				int records=pmstmt.executeUpdate();
				System.out.println("hello");
				if(records>0){
					fundTransfer="true";
				}
				else{
					fundTransfer="false";
				}
				
			}
			else{
				fundTransfer="false";
			}
			}
			else{
				fundTransfer="Wrong Transaction Password";
			}
			con.close();  
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return fundTransfer;
	}

	@Override
	public void blockAccount(String userName, String pwd) {
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			  
			//step3 create the statement object  
			Statement stmt=con.createStatement();  
			  
			//step4 execute query  
			//int rs=stmt.executeQuery("select account_no,login_password,lock_status from user_table where user_id='"+userName+"'");
			PreparedStatement pmstmt=con.prepareStatement(IQueryMapper.blockAccount);
			pmstmt.setString(1,userName);
			int rs=pmstmt.executeUpdate();
			if(rs>0){
				System.out.println("Account Blocked");
			}
			else{
				System.out.println("Failed to recognize user_id");
			}
			//step5 close the connection object  
			con.close();  
			  
			}catch(Exception e){ 
				//msg=e.getMessage();
			}
		
	}
	@Override
	public String getDetailedStatement(long account, String fromDate, String toDate) {
		StringBuilder sb=new StringBuilder();
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			  
			//step3 create the statement object  
			Statement stmt=con.createStatement();  
			  
			//step4 execute query  
			//int rs=stmt.executeQuery("select account_no,login_password,lock_status from user_table where user_id='"+userName+"'"); 
			//int rs=stmt.executeUpdate("Update user_table set lock_status='L' where user_id='"+userName+"'");
			//System.out.println("helo");
			PreparedStatement pmstmt=con.prepareStatement(IQueryMapper.detailedStatement);
			pmstmt.setLong(1, account);
			pmstmt.setString(2, fromDate);
			pmstmt.setString(3, toDate);
			ResultSet rs=pmstmt.executeQuery();
			//System.out.println("hello");
			if(rs!=null){
				while(rs.next()){
					//System.out.println("hello");
					sb.append(rs.getString(1)+"                    "+rs.getString(2)+"                  "+rs.getString(3)+"\n");
				}
			}
			/*if(rs>0){
				System.out.println("Account Blocked");
			}
			else{
				System.out.println("Failed to recognize user_id");
			}*/
			//step5 close the connection object  
			con.close();  
			  
			}catch(Exception e){ 
				//msg=e.getMessage();
			}
		return sb.toString();

	}
	@Override
	public boolean updateEmail(UserAccountBean useraccountbean) {
		boolean result = false;
		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();
			System.out.println(useraccountbean.getAccountNo());
			long acc=useraccountbean.getAccountNo();
			//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			String s1=IQueryMapper.updateEmail;
			PreparedStatement s=con.prepareStatement(s1);
			s.setString(1, useraccountbean.getEmail());
			s.setLong(2, useraccountbean.getAccountNo());
			//System.out.println("hello");
			int status=s.executeUpdate();
			//System.out.println("hello");
			//System.out.println(status);
			if(status>0){
				//System.out.println("hello");
				result = true;
			}
			else 
				{
				result = false;
				}
			
			con.commit();
			con.close();
		}
		catch(Exception e){
			
		}
		return result;

	}

	@Override
	public boolean updateAddress(UserAccountBean useraccountbean) {
boolean result = false;
		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();
			
			//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			String s1=IQueryMapper.updateAddress;
			PreparedStatement s=con.prepareStatement(s1);
			s.setString(1, useraccountbean.getAddress());
			s.setLong(2, useraccountbean.getAccountNo());
			int status=s.executeUpdate();
			if(status>0)
				result = true;
			else result = false;
			
			con.commit();
			con.close();
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return result;
	
	}
	@Override
	public String raiseCheckBookRequest(long account) {
		long service_id=0;
		String service_request=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			  
			//step3 create the statement object  
			Statement stmt=con.createStatement();
			String sql=IQueryMapper.checkBookReqService;
			String seq_id=IQueryMapper.serviceTrackerrequest;
			ResultSet rs=stmt.executeQuery(seq_id);
			if(rs!=null){
				while(rs.next()){
					service_id=rs.getLong(1);
				}
			}
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setLong(1,service_id);
			ps.setString(2, "CheckBook");
			ps.setLong(3, account);
			ps.setString(4, "OpenState");
			int result=ps.executeUpdate();
			if(result>0){
				service_request=Long.toString(service_id);
			}
			else{
				service_request="failed to generate check book request";
			}
			
		}
		catch(Exception e){
			
		}
		return service_request;
	}

	@Override
	public List<String> getAvailablePayees(long account) {
		long payee_account=0;
		String name;
		List<String> list=new ArrayList<String>(25);
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			  
			//step3 create the statement object  
			Statement stmt=con.createStatement();
			PreparedStatement pmstmt=con.prepareStatement(IQueryMapper.payeeList);
			pmstmt.setLong(1,account);
			ResultSet rs=pmstmt.executeQuery();
			if(rs!=null){
				while(rs.next()){
					payee_account=rs.getLong(1);
					name=rs.getString(2);
					list.add(payee_account+"   "+name+"\n");
				}
			}
			//System.out.println(list);
		}
		catch(Exception e){
			
		}
		return list;
	}

	@Override
	public String addNewPayee(long account, long pAccount,String nickName) {
		String result=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			  
			//step3 create the statement object  
			Statement stmt=con.createStatement();
			String s1=IQueryMapper.payeeData;
			PreparedStatement ps=con.prepareStatement(s1);
			ps.setLong(1,account);
			ps.setLong(2, pAccount);
			ps.setString(3, nickName);
			int record=ps.executeUpdate();
			if(record>0){
				result="true";
			}
			else{
				result="Payee Account Not Added";
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return result;
	}

	public String getServiceDetails(long serviceId,long accountNumber){
		StringBuilder str = new StringBuilder();
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();
				
			//String query = "SELECT service_description,service_status FROM serviceTracker WHERE service_id = ? AND account_no = ?";
					
			PreparedStatement s = con.prepareStatement(IQueryMapper.ServiceId);
			s.setLong(1,serviceId);
			s.setLong(2,accountNumber);
			ResultSet rs = s.executeQuery();
			if(rs.next()){
				System.out.println("reached");
					str.append("\nService Description: ");
					str.append(rs.getString(1));
					str.append("\nService Status: ");
					str.append(rs.getString(2));
				}
				else str.append("Not Found");
			
			con.commit();
			con.close();
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
			return str.toString();
	}
		
		
	public String getAllServiceDetails(long accountNumber){
		StringBuilder str = new StringBuilder();
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();
					
			//String query = "SELECT service_id,service_description,service_status FROM serviceTracker WHERE account_no = ? AND (SYSDATE-service_raised_date)<=180";
					
			PreparedStatement s = con.prepareStatement(IQueryMapper.ServiceRequests);
			s.setLong(1,accountNumber);
			ResultSet rs = s.executeQuery();
			if(rs.next()){
				str.append("Service Id: ");
				str.append(rs.getString(1));
				str.append("Service Description: ");
				str.append(rs.getString(2));
				str.append("\nService Status: ");
				str.append(rs.getString(3));
			}
			else str.append("Not Found");
				
			con.commit();
			con.close();
		}
		catch(Exception e){
				System.out.println(e.getMessage());
		}
		return str.toString();
	}

	
	@Override
	public String generateNewAccount(UserAccountBean bean) {
		String result = null;
		long accNum = 0;
			
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");   
		//step2 create  the connection object  
		Connection con=RechargeDBConnection.getConnection();
				
		//String query = "INSERT INTO Account_master VALUES(seq_acc_num.NEXTVAL,?,?,SYSDATE)";
		//System.out.println("Reached insert");
		PreparedStatement s = con.prepareStatement(IQueryMapper.AccountDetails);
			
		s.setString(1, bean.getAccType());
		s.setLong(2, bean.getBalance());
			
		int rows = s.executeUpdate();
		if(rows>0){
			//query="SELECT seq_acc_num.CURRVAL FROM DUAL";
			s = con.prepareStatement(IQueryMapper.AccountSeq);
			ResultSet rs = s.executeQuery();
			if(rs.next()){
				accNum = Long.parseLong(rs.getString(1));
				//query = "INSERT INTO Customer VALUES(?,?,?,?,?)";
				s = con.prepareStatement(IQueryMapper.CustomerDetails);
				s.setLong(1, accNum);
				s.setString(2, bean.getAccName());
				s.setString(3, bean.getEmail());
				s.setString(4, bean.getAddress());
				s.setString(5, bean.getPanCard());
				rows = s.executeUpdate();
				if(rows>0){
					result="success";
				}
				else result="fail";
			}
			else{
				result="fail";
			}
		}
		else result="fail";
		System.out.println("Result = "+result);
			con.commit();
			con.close();
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		
			
		return result;
	}

	@Override
	public String getYearTransaction(int year) {
		StringBuilder sb=new StringBuilder();
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select transaction_id,account_no,transaction_date from transactions where extract(year from transaction_date)='"+year+"'");
			if(rs!=null){
				while(rs.next()){
					sb.append(rs.getString(1)+"              "+rs.getString(2)+"                "+rs.getString(3)+"\n");
				}
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return sb.toString();
	}

	@Override
	public String generateMonthTransaction(int month) {
		StringBuilder sb=new StringBuilder();
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select transaction_id,account_no,transaction_date from transactions where extract(month from transaction_date)='"+month+"'");
			if(rs!=null){
				while(rs.next()){
					sb.append(rs.getString(1)+"              "+rs.getString(2)+"                "+rs.getString(3)+"\n");
				}
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return sb.toString();
	}

	@Override
	public String generateDateTransaction(int date) {
		StringBuilder sb=new StringBuilder();
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select transaction_id,account_no,transaction_date from transactions where extract(date from transaction_date)='"+date+"'");
			if(rs!=null){
				while(rs.next()){
					sb.append(rs.getString(1)+"              "+rs.getString(2)+"                "+rs.getString(3)+"\n");
				}
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return sb.toString();
	}
	
	

}

