package com.capgemini.onlineBanking.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.onlineBanking.bean.UserAccountBean;
import com.capgemini.onlineBanking.dao.IUserLogin;
import com.capgemini.onlineBanking.dao.UserLoginDB;
import com.capgemini.onlineBanking.exception.onlineBankingException;

public class UserAccount implements IUserAccount{

	@Override
	public String isValidUser(String userName, String pwd) {
		
		String result;
		IUserLogin il=new UserLoginDB();
		result=il.LoginValidation(userName,pwd);
		
		return result;
	}

	@Override
	public boolean getRegistered(UserAccountBean useraccountbean) throws onlineBankingException {
		boolean result;
		IUserLogin il=new UserLoginDB();
		result=il.getRegistered(useraccountbean);
		return false;
	}

	@Override
	public String getMiniStatement(long account) throws ClassNotFoundException, IOException, SQLException {
		String result;
		IUserLogin il=new UserLoginDB();
		result=il.getMiniStatement(account);
		return result;
	}

	@Override
	public boolean validatePayee(long account, long paccount) {
		boolean pdetails;
		IUserLogin il=new UserLoginDB();
		pdetails=il.validatePayee(account,paccount);
		return pdetails;
	}

	@Override
	public String transferFund(long account, long paccount, int amount,String password) {
		String transferFund;
		IUserLogin il=new UserLoginDB();
		transferFund=il.transferFunds(account,paccount,amount,password);
		return transferFund;
	}

	@Override
	public void blockAccount(String userName, String pwd) {
		IUserLogin il=new UserLoginDB();
		il.blockAccount(userName,pwd);
		
	}
	@Override
	public String getDetailedStatement(long account, String fromDate, String toDate) {
		String detailedStatement;
		IUserLogin il=new UserLoginDB();
		detailedStatement=il.getDetailedStatement(account,fromDate,toDate);
		
		
		return detailedStatement;
	}
	@Override
	public boolean updateEmail(UserAccountBean useraccountbean) {
		boolean updateStatus;
		IUserLogin il=new UserLoginDB();
		updateStatus=il.updateEmail(useraccountbean);
		return updateStatus;
	}

	@Override
	public boolean updateAddress(UserAccountBean useraccountbean) {
		boolean updateStatus;
		IUserLogin il=new UserLoginDB();
		updateStatus=il.updateAddress(useraccountbean);
		return updateStatus;
	}
	@Override
	public String raiseCheckBook(long account) {
		String checkbookRequest;
		IUserLogin il=new UserLoginDB();
		checkbookRequest=il.raiseCheckBookRequest(account);
		return checkbookRequest;
	}

	@Override
	public List<String> getAvailablePayees(long account) {
		List<String> payees=new ArrayList<>(20);
		IUserLogin il=new UserLoginDB();
		payees=il.getAvailablePayees(account);
		return payees;
	}

	@Override
	public String addNewPayee(long account, long pAccount,String nickName) {
		String addPayee;
		IUserLogin il=new UserLoginDB();
		addPayee=il.addNewPayee(account,pAccount,nickName);
		return addPayee;
	}
	
	public String getServiceDetails(long serviceId,long accNumber){
		IUserLogin dao = new UserLoginDB();
			
		String desc = dao.getServiceDetails(serviceId,accNumber);
		return desc;
	}
		
	public String getAllServiceDetails(long accNumber){
		IUserLogin dao = new UserLoginDB();
			
		String desc = dao.getAllServiceDetails(accNumber);
		return desc;
	}
	
	@Override
	public String generateNewAccount(UserAccountBean bean) {
		IUserLogin dao = new UserLoginDB();
			
		String result = dao.generateNewAccount(bean);
			
		return result;
	}

	@Override
	public String getYearlyTransaction(int year) {
		String transactions;
		IUserLogin dao = new UserLoginDB();
		transactions=dao.getYearTransaction(year);
		return transactions;
	}

	@Override
	public String getMonthlyTransaction(int month) {
		String transactions;
		IUserLogin dao = new UserLoginDB();
		transactions=dao.generateMonthTransaction(month);
		return transactions;
	}

	@Override
	public String getDateTransaction(int date) {
		String transactions;
		IUserLogin dao = new UserLoginDB();
		transactions=dao.generateDateTransaction(date);
		return transactions;
	}

}
